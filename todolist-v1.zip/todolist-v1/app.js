//jshint esversion:6
const express= require("express");
const bodyParser=require("body-parser");
const date=require(__dirname+"/date.js");//date.js module included here getDate and getDay came here
//console.log(date());//calling is done here
const app=express();
let items =["netflix","maggie","tea"]; //so instead of var item storing 1 value make it array for large value taaki last value ko bs update na kre //we can also simplify by var items=["buyfood","cook food","eat food"]; and deleting from there ejs //
let workItems=[]; //it can also be work as js allows for array and object
app.set('view engine', 'ejs');//tells our app to use ejs
app.use(bodyParser.urlencoded({extended:true}));
app.use(express.static("public")); //to use static files such as css
app.get("/",function(req,res){ //1  //7 //14
  ///server(android  visiual studio on which we work) ->browser
 

 //var currentDay=today.getDay();
 //var day="";
 //if(currentDay===6||currentDay===0){//0 for sunday 6  for sat
   // day="Weekend";
    //list file must exist in folder that is views and {this is js object with key -value pair key must be same as <%=ejs%>and value is  value of variable day }

   // res.write("<h1>yayaaaa!!!!!!holiday</h1>");
 //}
 //else{
   // day="Weekday";
   // res.write("<p>no weekend!!!!</p>");
    //res.write for multiple msgs //we have to write h and p in all else wont work
   // res.write("<h1>boooo i have to work</h1>");
   // res.send();
 //}
/*switch(currentDay){
    case 0:
        day="sunday";
        break;
    case 1:
        day="monday";
        break;
    case 2:
        day="tuesday";
        break;
    case 3:
        day="wednesday";
        break;
    case 4:
        day="thursday";
        break;
    case 5:
        day="friday";
        break;
    case 6:
        day="saturday";
        break;
    default:
        console.log("error!!!! current day in which error occured"+currentDay);

 }*/
let day=date.getDate();
 res.render('list', {listTitle: day,newListItems:items}); //2 //8 //15
});
app.post("/",function(req,res){ //5,12
let item=req.body.newItem; //item only exit in post not in get so instead of local crated it global(items)bt here 1 (item)and appended to items array
if(req.body.button==="Work List"){
    workItems.push(item);
    console.log(workItems);
    console.log(req.body);
    res.redirect("/work");
}else
{
    items.push(item);
 console.log(items);
 console.log(req.body);
 res.redirect("/");//it will go to home page app .get //6,13
}

});
app.get("/work",function(req,res){  //9
  res.render("list",{ listTitle:"Work List",newListItems:workItems});
});
app.get("/about",function(req,res){
   res.render("about");
});

app.listen(3000,function(){
 console.log("server started on port 3000");
});