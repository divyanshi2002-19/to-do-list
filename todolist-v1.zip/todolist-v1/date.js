//jshint esversion:6
//console.log(module);
module.exports.getDate=getDate;//whatever we want to export in app.js we write here //exports.getDate=getDate

function getDate(){
const today=new Date();
 const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };



const day=today.toLocaleDateString("en-US", options); // Saturday, September 17, 2016 //we can use reate here itself
return day;
}
module.exports.getDay=getDay;
function getDay(){
    const today=new Date();
     const options = { weekday: 'long' };
    
    
    
    const day=today.toLocaleDateString("en-US", options); // Saturday, September 17, 2016
    return day;
    }
    console.log(module.exports);